# Fractals
1. Mandelbrot set [망델브로 집합](mandelbrot.md)
2. Julia set [줄리아 집합](julia.md)
3. Burningship set
4. Tricorn set
5. Bifurcation diagram of logistic map 
6. 3D Mandelbrot set
7. 3D Julia set
8. 3D Burningship set
9. 3D Tricorn set
